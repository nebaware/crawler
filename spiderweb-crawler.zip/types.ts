
export interface CrawlResult {
  url: string;
  title: string;
  summary: string;
  links: string[];
  sourceUrls?: { title: string; uri: string }[];
  timestamp: number;
  depth: number;
  status: 'success' | 'error';
  error?: string;
}

export interface QueueItem {
  url: string;
  depth: number;
  status: 'pending' | 'processing' | 'completed' | 'failed';
}

export interface CrawlerStats {
  pagesCrawled: number;
  queueLength: number;
  activeThreads: number;
  errors: number;
  startTime: number | null;
}

export interface GraphNode {
  id: string;
  group: number;
  url: string;
}

export interface GraphLink {
  source: string;
  target: string;
}

export interface GraphData {
  nodes: GraphNode[];
  links: GraphLink[];
}
