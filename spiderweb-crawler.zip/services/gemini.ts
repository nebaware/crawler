
import { GoogleGenAI } from "@google/genai";

const systemInstruction = `
You are a highly efficient web crawler parser. 
Your task is to visit a given URL (using your search capabilities), analyze its content, and extract structured data.

MANDATORY: You must return a valid JSON object strictly inside a markdown code block \`\`\`json ... \`\`\`.
Do not include any conversational text outside the JSON block.

The JSON object must have the following fields:
- title: The title of the page.
- summary: A concise 2-sentence summary of the page content.
- links: An array of strings, containing up to 4 relevant, distinct outbound URLs found on this page that would be interesting to crawl next. Do not include navigation links like 'Home' or 'Contact'. Focus on content links. If real links cannot be resolved, infer plausible related URLs based on the content.

If you cannot access the page or it doesn't exist, return a JSON with status "error".
`;

export class GeminiService {
  private ai: GoogleGenAI;

  constructor() {
    this.ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  }

  async crawlUrl(url: string): Promise<{ title: string; summary: string; links: string[]; sourceUrls: { title: string; uri: string }[] }> {
    try {
      const response = await this.ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: `Crawl this URL: ${url}`,
        config: {
            systemInstruction: systemInstruction,
            tools: [{ googleSearch: {} }],
            temperature: 0.1,
        }
      });

      const text = response.text;
      if (!text) throw new Error("No response from AI");

      let data: any = {};
      // Extract JSON
      const jsonMatch = text.match(/```json\s*([\s\S]*?)\s*```/);
      if (jsonMatch && jsonMatch[1]) {
          try {
              data = JSON.parse(jsonMatch[1]);
          } catch (e) {
              console.error("JSON Parse Error", e);
              data = { title: "Parse Error", summary: text.slice(0, 100), links: [] };
          }
      } else {
          // Fallback try to parse raw if model forgot code blocks
          try {
              // Attempt to find anything that looks like JSON
              const rawMatch = text.match(/\{[\s\S]*\}/);
              if (rawMatch) {
                  data = JSON.parse(rawMatch[0]);
              } else {
                  throw new Error("No JSON found");
              }
          } catch (e) {
              console.warn("Failed to parse JSON from Gemini response, using fallback");
              data = { title: "Unstructured Content", summary: text.slice(0, 200), links: [] };
          }
      }

      // Extract Grounding Sources (Search Results)
      const chunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks || [];
      const sourceUrls = chunks
        .map((chunk: any) => {
             if (chunk.web) return { title: chunk.web.title || "Source", uri: chunk.web.uri };
             return null;
        })
        .filter((s: any) => s !== null && s.uri);

      return {
          title: data.title || "No Title",
          summary: data.summary || "No Summary",
          links: Array.isArray(data.links) ? data.links : [],
          sourceUrls
      };

    } catch (error) {
      console.error("Gemini Crawl Error:", error);
      throw error;
    }
  }
}

export const geminiService = new GeminiService();