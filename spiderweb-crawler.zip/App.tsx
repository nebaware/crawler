
import React, { useState, useRef, useEffect, useCallback } from 'react';
import { ControlPanel } from './components/ControlPanel';
import { StatsCard } from './components/StatsCard';
import { GraphView } from './components/GraphView';
import { ResultsTable } from './components/ResultsTable';
import { Presentation } from './components/Presentation'; // Import Presentation
import { geminiService } from './services/gemini';
import { dbService } from './services/db';
import { QueueItem, CrawlerStats, GraphData, CrawlResult, GraphNode, GraphLink } from './types';
import { MAX_DEPTH_DEFAULT, MAX_PAGES_LIMIT } from './constants';
import { Presentation as PresentationIcon, LayoutDashboard } from 'lucide-react';

// System logger
const log = (msg: string) => console.log(`[SpiderWeb] ${msg}`);

export default function App() {
  // --- State ---
  const [showPresentation, setShowPresentation] = useState(true); // Default to true
  const [isRunning, setIsRunning] = useState(false);
  const [queue, setQueue] = useState<QueueItem[]>([]);
  const [activeUrls, setActiveUrls] = useState<Set<string>>(new Set());
  const [crawledCount, setCrawledCount] = useState(0);
  const [startTime, setStartTime] = useState<number | null>(null);
  const [concurrencyLimit, setConcurrencyLimit] = useState(2);
  
  // Data for graph
  const [graphData, setGraphData] = useState<GraphData>({ nodes: [], links: [] });
  
  // Trigger for results table refresh
  const [refreshTrigger, setRefreshTrigger] = useState(0);

  // Refs for mutable state to avoid closure staleness during async ops
  const queueRef = useRef<QueueItem[]>([]);
  const activeUrlsRef = useRef<Set<string>>(new Set());
  const visitedRef = useRef<Set<string>>(new Set());
  const isRunningRef = useRef(false);
  const crawledCountRef = useRef(0);
  const graphNodesRef = useRef<GraphNode[]>([]);
  const graphLinksRef = useRef<GraphLink[]>([]);

  // Initialize stats on load
  useEffect(() => {
    dbService.getAllPages().then(pages => {
      setCrawledCount(pages.length);
      crawledCountRef.current = pages.length;
    });
  }, []);

  // --- Crawler Engine ---

  // The Main Driver Effect: Watches state and dispatches workers
  useEffect(() => {
    if (!isRunning) return;

    // 1. Check limits
    if (crawledCount >= MAX_PAGES_LIMIT) {
        log("Max pages reached. Stopping.");
        handleStop();
        return;
    }

    // 2. Determine available capacity
    const activeCount = activeUrls.size;
    const availableSlots = concurrencyLimit - activeCount;

    // If no slots or nothing to do, just wait
    if (availableSlots <= 0) return;

    // 3. Find pending work
    const pendingItems = queueRef.current.filter(item => item.status === 'pending');

    // Check for completion condition
    if (pendingItems.length === 0 && activeCount === 0) {
        log("All tasks completed.");
        handleStop();
        return;
    }

    if (pendingItems.length === 0) return;

    // 4. Dispatch Workers
    const tasksToStart = pendingItems.slice(0, availableSlots);
    
    // Optimistically update state before async work starts to prevent double-scheduling
    tasksToStart.forEach(item => {
        const idx = queueRef.current.findIndex(q => q.url === item.url);
        if (idx !== -1) {
            queueRef.current[idx].status = 'processing';
        }
        activeUrlsRef.current.add(item.url);
    });

    // Sync State to trigger UI updates and lock the effect from re-running on same items
    setQueue([...queueRef.current]);
    setActiveUrls(new Set(activeUrlsRef.current));

    // Fire and forget workers (they will update state on completion)
    tasksToStart.forEach(item => {
        crawlWorker(item);
    });

  }, [queue, activeUrls, isRunning, concurrencyLimit, crawledCount]);


  const crawlWorker = async (item: QueueItem) => {
    try {
      log(`Worker Start: ${item.url}`);

      // Check DB cache
      const existing = await dbService.getPage(item.url);
      let resultData: { title: string, summary: string, links: string[], sourceUrls: { title: string, uri: string }[] };

      if (existing) {
        log(`Cache Hit: ${item.url}`);
        resultData = { 
            title: existing.title, 
            summary: existing.summary, 
            links: existing.links,
            sourceUrls: existing.sourceUrls || []
        };
      } else {
        // Real Crawl via Gemini
        resultData = await geminiService.crawlUrl(item.url);
      }

      if (!isRunningRef.current) return; // Abort if stopped during await

      // Process found links
      if (item.depth < MAX_DEPTH_DEFAULT) {
        for (const link of resultData.links) {
          // Simple normalization/dedup logic
          if (!visitedRef.current.has(link) && !queueRef.current.some(q => q.url === link)) {
            visitedRef.current.add(link);
            
            // Add to queue
            queueRef.current.push({ url: link, depth: item.depth + 1, status: 'pending' });
            
            // Add to graph
            graphNodesRef.current.push({ id: link, group: 1, url: link });
            graphLinksRef.current.push({ source: item.url, target: link });
          }
        }
      }

      // Save Result
      const crawlResult: CrawlResult = {
        url: item.url,
        title: resultData.title,
        summary: resultData.summary,
        links: resultData.links,
        sourceUrls: resultData.sourceUrls,
        timestamp: Date.now(),
        depth: item.depth,
        status: 'success'
      };
      await dbService.savePage(crawlResult);

      // Update Refs
      crawledCountRef.current += 1;
      const qIdx = queueRef.current.findIndex(q => q.url === item.url);
      if (qIdx !== -1) queueRef.current[qIdx].status = 'completed';
      activeUrlsRef.current.delete(item.url);

      // Sync Graph
      setGraphData({
          nodes: [...graphNodesRef.current],
          links: [...graphLinksRef.current]
      });

    } catch (error) {
      console.error(`Failed to crawl ${item.url}`, error);
      
      const qIdx = queueRef.current.findIndex(q => q.url === item.url);
      if (qIdx !== -1) queueRef.current[qIdx].status = 'failed';
      activeUrlsRef.current.delete(item.url);
    } finally {
        // Final State Sync to trigger Effect for next batch
        if (isRunningRef.current) {
            setCrawledCount(crawledCountRef.current);
            setQueue([...queueRef.current]);
            setActiveUrls(new Set(activeUrlsRef.current));
            setRefreshTrigger(prev => prev + 1);
        }
    }
  };

  // --- Control Handlers ---

  const handleStart = (seedUrl: string, concurrency: number) => {
    setConcurrencyLimit(concurrency);
    setIsRunning(true);
    isRunningRef.current = true;
    setStartTime(Date.now());

    // Reset
    const initialItem: QueueItem = { url: seedUrl, depth: 0, status: 'pending' };
    queueRef.current = [initialItem];
    setQueue([initialItem]);
    
    visitedRef.current = new Set([seedUrl]);
    activeUrlsRef.current = new Set();
    setActiveUrls(new Set());
    
    // Reset graph
    graphNodesRef.current = [{ id: seedUrl, group: 0, url: seedUrl }];
    graphLinksRef.current = [];
    setGraphData({ nodes: [...graphNodesRef.current], links: [] });
  };

  const handleStop = () => {
    setIsRunning(false);
    isRunningRef.current = false;
    setStartTime(null);
  };

  const handleClear = async () => {
    await dbService.clear();
    setCrawledCount(0);
    crawledCountRef.current = 0;
    setRefreshTrigger(prev => prev + 1);
    setGraphData({ nodes: [], links: [] });
    setQueue([]);
    queueRef.current = [];
    visitedRef.current = new Set();
  };

  if (showPresentation) {
    return <Presentation onClose={() => setShowPresentation(false)} />;
  }

  return (
    <div className="min-h-screen bg-slate-950 p-6 md:p-12 font-sans text-slate-200">
      <div className="max-w-7xl mx-auto">
        
        {/* Header */}
        <header className="mb-8 flex justify-between items-start">
          <div>
            <h1 className="text-4xl font-black text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-blue-600 mb-2">
              SPIDER<span className="text-slate-100">WEB</span>
            </h1>
            <p className="text-slate-400 text-lg max-w-2xl">
              Enterprise-grade concurrent web crawler. Powered by Gemini AI with Google Search Grounding for real-time content discovery and analytics.
            </p>
          </div>
          <button 
            onClick={() => setShowPresentation(true)}
            className="flex items-center gap-2 px-4 py-2 bg-slate-800 hover:bg-slate-700 rounded-lg text-slate-300 hover:text-white transition-colors text-sm font-medium border border-slate-700"
          >
            <PresentationIcon className="w-4 h-4" />
            Presentation (14 Slides)
          </button>
        </header>

        {/* Stats & Controls */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
          <div className="lg:col-span-2">
             <StatsCard stats={{
                pagesCrawled: crawledCount,
                queueLength: queue.filter(q => q.status === 'pending').length,
                activeThreads: activeUrls.size,
                errors: queue.filter(q => q.status === 'failed').length,
                startTime: startTime
             }} />
             <GraphView data={graphData} />
          </div>

          <div className="lg:col-span-1 flex flex-col gap-6">
             <ControlPanel 
                isRunning={isRunning} 
                onStart={handleStart} 
                onStop={handleStop} 
                onClear={handleClear}
              />
              
              {/* Live Queue Monitor */}
              <div className="bg-slate-900 rounded-xl border border-slate-800 shadow-lg flex-1 overflow-hidden flex flex-col min-h-[300px]">
                 <div className="p-4 border-b border-slate-800 bg-slate-900/50">
                    <h3 className="text-sm font-bold text-slate-400 uppercase tracking-wider flex items-center gap-2">
                      Live Thread Activity
                      <span className="text-xs bg-slate-800 px-2 py-0.5 rounded text-slate-300">
                        {activeUrls.size} / {concurrencyLimit}
                      </span>
                    </h3>
                 </div>
                 <div className="flex-1 overflow-y-auto p-4 space-y-3">
                    {Array.from(activeUrls).map(url => (
                      <div key={url} className="bg-slate-950/50 border border-cyan-500/30 p-3 rounded-lg animate-pulse">
                        <div className="flex items-center justify-between mb-1">
                           <span className="text-xs font-bold text-cyan-400 uppercase">Crawling</span>
                           <span className="text-xs text-cyan-500/70">Thread Active</span>
                        </div>
                        <div className="text-sm text-slate-300 truncate font-mono">{url}</div>
                      </div>
                    ))}
                    {activeUrls.size === 0 && isRunning && (
                       <div className="text-center text-slate-600 py-8 italic">Waiting for tasks...</div>
                    )}
                    {!isRunning && activeUrls.size === 0 && (
                        <div className="text-center text-slate-600 py-8">Crawler is idle.</div>
                    )}
                 </div>
              </div>
          </div>
        </div>

        {/* Data Table */}
        <div className="w-full">
           <ResultsTable refreshTrigger={refreshTrigger} />
        </div>

      </div>
    </div>
  );
}