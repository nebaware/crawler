
import React, { useState, useEffect, useCallback } from 'react';
import { 
  Users, Target, Cpu, Database, Globe, ArrowRight, CheckCircle, 
  ChevronRight, ChevronLeft, Zap, Shield, BarChart, Network, Layers,
  BrainCircuit, Lock
} from 'lucide-react';

interface PresentationProps {
  onClose: () => void;
}

export const Presentation: React.FC<PresentationProps> = ({ onClose }) => {
  const [currentSlide, setCurrentSlide] = useState(0);
  const [animating, setAnimating] = useState(false);

  const team = [
    "Etsubdink Arega",
    "Nebiyu Tegaye",
    "Muluken Ugamo",
    "Keneni Junedi",
    "Mahlet Fekadewold",
    "Ruhama Kassahun"
  ];

  const slides = [
    {
      id: 'title',
      render: () => (
        <div className="flex flex-col items-center justify-center text-center h-full animate-fade-in">
           <div className="inline-flex items-center gap-2 bg-cyan-500/10 border border-cyan-500/30 rounded-full px-4 py-1 backdrop-blur-sm mb-8">
              <CheckCircle className="w-4 h-4 text-cyan-400" />
              <span className="text-cyan-300 text-xs font-bold uppercase tracking-wider">Production Release v1.0.0</span>
           </div>
           <h1 className="text-6xl md:text-8xl font-black text-white mb-6 tracking-tight">
              SPIDER<span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-blue-500">WEB</span>
           </h1>
           <p className="text-xl md:text-3xl text-slate-400 font-light tracking-wide max-w-3xl mb-12">
              Enterprise-Grade Concurrent Web Crawler powered by Generative AI
           </p>
           <div className="flex items-center gap-4 text-sm font-mono text-slate-500">
             <span>Group 8 Capstone Project</span>
             <span className="w-1 h-1 bg-slate-600 rounded-full"></span>
             <span>2025</span>
           </div>
        </div>
      )
    },
    {
      id: 'problem',
      title: "The Data Challenge",
      icon: <Lock className="w-6 h-6 text-rose-400" />,
      render: () => (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center h-full">
          <div className="space-y-6">
            <h2 className="text-4xl font-bold text-white">The Unstructured Web</h2>
            <p className="text-lg text-slate-300 leading-relaxed">
              The internet contains petabytes of data, but 90% of it is unstructured. Manual data extraction is:
            </p>
            <ul className="space-y-4">
              <li className="flex items-center gap-3 bg-slate-800/50 p-4 rounded-lg border border-slate-800">
                <div className="w-2 h-2 bg-rose-500 rounded-full"></div>
                <span className="text-slate-200">Slow and labor-intensive</span>
              </li>
              <li className="flex items-center gap-3 bg-slate-800/50 p-4 rounded-lg border border-slate-800">
                <div className="w-2 h-2 bg-rose-500 rounded-full"></div>
                <span className="text-slate-200">Prone to human error</span>
              </li>
              <li className="flex items-center gap-3 bg-slate-800/50 p-4 rounded-lg border border-slate-800">
                <div className="w-2 h-2 bg-rose-500 rounded-full"></div>
                <span className="text-slate-200">Lacks contextual understanding</span>
              </li>
            </ul>
          </div>
          <div className="bg-slate-900 p-8 rounded-2xl border border-slate-800 shadow-xl flex items-center justify-center">
             <div className="text-center space-y-4 opacity-50">
                <div className="h-4 w-3/4 bg-slate-700 rounded mx-auto"></div>
                <div className="h-4 w-full bg-slate-700 rounded"></div>
                <div className="h-4 w-5/6 bg-slate-700 rounded mx-auto"></div>
                <div className="h-4 w-full bg-slate-700 rounded"></div>
                <div className="text-rose-500 font-mono mt-8">Error: Cannot parse semantics</div>
             </div>
          </div>
        </div>
      )
    },
    {
      id: 'solution',
      title: "The Solution",
      icon: <Zap className="w-6 h-6 text-amber-400" />,
      render: () => (
        <div className="flex flex-col items-center justify-center h-full text-center max-w-4xl mx-auto">
          <h2 className="text-4xl font-bold text-white mb-8">Autonomous Intelligence</h2>
          <p className="text-xl text-slate-300 leading-relaxed mb-12">
            SpiderWeb is not just a script; it's an <strong>autonomous agent</strong>. It doesn't just download HTML; it reads, understands, and indexes content like a human, but at the speed of a machine.
          </p>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 w-full">
             <div className="bg-slate-800 p-6 rounded-xl border border-slate-700">
                <h3 className="text-cyan-400 font-bold text-lg mb-2">Read</h3>
                <p className="text-sm text-slate-400">Fetches raw content from any URL.</p>
             </div>
             <div className="bg-slate-800 p-6 rounded-xl border border-slate-700">
                <h3 className="text-violet-400 font-bold text-lg mb-2">Understand</h3>
                <p className="text-sm text-slate-400">Uses Gemini AI to summarize & extract.</p>
             </div>
             <div className="bg-slate-800 p-6 rounded-xl border border-slate-700">
                <h3 className="text-emerald-400 font-bold text-lg mb-2">Connect</h3>
                <p className="text-sm text-slate-400">Follows semantic links intelligently.</p>
             </div>
          </div>
        </div>
      )
    },
    {
      id: 'architecture',
      title: "System Architecture",
      icon: <Layers className="w-6 h-6 text-blue-400" />,
      render: () => (
        <div className="h-full flex flex-col justify-center">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 text-center">
             
             <div className="flex flex-col items-center space-y-4 group">
                <div className="w-20 h-20 bg-slate-800 rounded-2xl flex items-center justify-center border border-slate-700 group-hover:border-blue-500 transition-colors shadow-lg">
                   <Users className="w-10 h-10 text-blue-400" />
                </div>
                <div className="h-16 w-0.5 bg-slate-700"></div>
                <span className="font-bold text-slate-200">User Interface</span>
                <span className="text-xs text-slate-500">React 19</span>
             </div>

             <div className="flex flex-col items-center space-y-4 group mt-12 md:mt-0">
                <div className="w-20 h-20 bg-slate-800 rounded-2xl flex items-center justify-center border border-slate-700 group-hover:border-amber-500 transition-colors shadow-lg">
                   <Cpu className="w-10 h-10 text-amber-400" />
                </div>
                <div className="h-16 w-0.5 bg-slate-700"></div>
                <span className="font-bold text-slate-200">Event Loop</span>
                <span className="text-xs text-slate-500">Worker Manager</span>
             </div>

             <div className="flex flex-col items-center space-y-4 group">
                <div className="w-20 h-20 bg-slate-800 rounded-2xl flex items-center justify-center border border-slate-700 group-hover:border-violet-500 transition-colors shadow-lg">
                   <BrainCircuit className="w-10 h-10 text-violet-400" />
                </div>
                <div className="h-16 w-0.5 bg-slate-700"></div>
                <span className="font-bold text-slate-200">Gemini AI</span>
                <span className="text-xs text-slate-500">Analysis Engine</span>
             </div>

             <div className="flex flex-col items-center space-y-4 group mt-12 md:mt-0">
                <div className="w-20 h-20 bg-slate-800 rounded-2xl flex items-center justify-center border border-slate-700 group-hover:border-emerald-500 transition-colors shadow-lg">
                   <Database className="w-10 h-10 text-emerald-400" />
                </div>
                <div className="h-16 w-0.5 bg-slate-700"></div>
                <span className="font-bold text-slate-200">Storage</span>
                <span className="text-xs text-slate-500">IndexedDB</span>
             </div>

          </div>
          <div className="mt-12 text-center text-slate-500 italic border-t border-slate-800 pt-8">
             High-throughput asynchronous data pipeline
          </div>
        </div>
      )
    },
    {
      id: 'ai-core',
      title: "The Brain: Gemini 2.5 Flash",
      icon: <BrainCircuit className="w-6 h-6 text-violet-400" />,
      render: () => (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center h-full">
          <div className="bg-violet-900/10 p-8 rounded-2xl border border-violet-500/20">
             <pre className="text-xs md:text-sm font-mono text-violet-300 overflow-x-auto">
{`{
  "title": "Extracted Page Title",
  "summary": "Concise 2-sentence summary...",
  "links": [
    "https://related-link-1.com",
    "https://related-link-2.com"
  ]
}`}
             </pre>
          </div>
          <div className="space-y-6">
            <h2 className="text-3xl font-bold text-white">Structured Extraction</h2>
            <p className="text-slate-300">
               Traditional crawlers rely on brittle Regex or DOM selectors. SpiderWeb uses <strong>Gemini 2.5 Flash</strong> to:
            </p>
            <ul className="space-y-3 text-slate-400">
               <li className="flex items-center gap-2">
                  <CheckCircle className="w-4 h-4 text-violet-500" />
                  <span>Parse unstructured text into strictly typed JSON.</span>
               </li>
               <li className="flex items-center gap-2">
                  <CheckCircle className="w-4 h-4 text-violet-500" />
                  <span>Infer relationships between content.</span>
               </li>
               <li className="flex items-center gap-2">
                  <CheckCircle className="w-4 h-4 text-violet-500" />
                  <span>Ignore navigation/footer clutter automatically.</span>
               </li>
            </ul>
          </div>
        </div>
      )
    },
    {
      id: 'grounding',
      title: "The Eyes: Google Search Grounding",
      icon: <Globe className="w-6 h-6 text-blue-400" />,
      render: () => (
        <div className="flex flex-col items-center justify-center h-full text-center max-w-4xl mx-auto">
          <div className="p-4 bg-blue-500/10 rounded-full mb-6">
             <Globe className="w-16 h-16 text-blue-400" />
          </div>
          <h2 className="text-4xl font-bold text-white mb-6">Real-Time Verification</h2>
          <p className="text-xl text-slate-300 leading-relaxed mb-8">
             AI Hallucinations are a risk. We mitigate this using <strong>Google Search Grounding</strong>.
          </p>
          <div className="bg-slate-800/80 p-6 rounded-xl border-l-4 border-blue-500 text-left w-full max-w-2xl">
             <h4 className="font-bold text-white mb-2">Grounding Process:</h4>
             <ol className="list-decimal list-inside text-slate-400 space-y-2">
                <li>Crawler encounters a topic.</li>
                <li>Gemini queries Google Search Index.</li>
                <li>Returns <strong>actual, live URLs</strong> and metadata.</li>
                <li>Ensures every link in our graph is valid and reachable.</li>
             </ol>
          </div>
        </div>
      )
    },
    {
      id: 'concurrency',
      title: "The Engine: Concurrency",
      icon: <Cpu className="w-6 h-6 text-cyan-400" />,
      render: () => (
        <div className="h-full flex flex-col justify-center space-y-8">
          <h2 className="text-3xl font-bold text-white">Parallel Processing</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
             <div className="bg-slate-900 p-6 rounded-xl border border-slate-800 relative overflow-hidden">
                <div className="absolute top-0 left-0 w-full h-1 bg-cyan-500 animate-pulse"></div>
                <span className="text-xs font-bold text-cyan-500 uppercase">Thread 1</span>
                <div className="mt-2 text-slate-300 font-mono text-sm">Fetching...</div>
             </div>
             <div className="bg-slate-900 p-6 rounded-xl border border-slate-800 relative overflow-hidden">
                <div className="absolute top-0 left-0 w-full h-1 bg-cyan-500 animate-pulse delay-75"></div>
                <span className="text-xs font-bold text-cyan-500 uppercase">Thread 2</span>
                <div className="mt-2 text-slate-300 font-mono text-sm">Parsing JSON...</div>
             </div>
             <div className="bg-slate-900 p-6 rounded-xl border border-slate-800 relative overflow-hidden opacity-50">
                <div className="absolute top-0 left-0 w-full h-1 bg-slate-700"></div>
                <span className="text-xs font-bold text-slate-500 uppercase">Thread 3</span>
                <div className="mt-2 text-slate-500 font-mono text-sm">Idle</div>
             </div>
          </div>
          <p className="text-slate-400 max-w-2xl">
             We implement a custom event loop that manages a dynamic pool of workers. This prevents browser UI freezing while maintaining high throughput, adhering to rate limits via adaptive backoff.
          </p>
        </div>
      )
    },
    {
      id: 'persistence',
      title: "The Memory: IndexedDB",
      icon: <Database className="w-6 h-6 text-emerald-400" />,
      render: () => (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center h-full">
           <div className="space-y-6">
              <h2 className="text-3xl font-bold text-white">Zero Latency Access</h2>
              <p className="text-slate-300">
                 Unlike `localStorage` (limited to 5MB), we use <strong>IndexedDB</strong> for high-performance, transactional storage of megabytes of crawled data.
              </p>
              <div className="flex gap-4">
                 <div className="text-center">
                    <div className="text-2xl font-bold text-emerald-400">~500ms</div>
                    <div className="text-xs text-slate-500">Read Speed</div>
                 </div>
                 <div className="text-center">
                    <div className="text-2xl font-bold text-emerald-400">Unltd</div>
                    <div className="text-xs text-slate-500">Capacity*</div>
                 </div>
              </div>
           </div>
           <div className="bg-emerald-900/10 p-8 rounded-full border border-emerald-500/20 flex items-center justify-center aspect-square">
              <Database className="w-32 h-32 text-emerald-500 opacity-80" />
           </div>
        </div>
      )
    },
    {
      id: 'visualization',
      title: "The Map: D3 Visualization",
      icon: <Network className="w-6 h-6 text-pink-400" />,
      render: () => (
        <div className="flex flex-col items-center justify-center h-full text-center">
           <Network className="w-20 h-20 text-pink-400 mb-8" />
           <h2 className="text-3xl font-bold text-white mb-4">Force-Directed Graph Theory</h2>
           <p className="text-slate-400 max-w-2xl mb-8">
              We visualize the internet as it really is: a complex network of nodes (pages) and edges (links). 
              Using <strong>D3.js</strong>, we render real-time topology changes as the crawler discovers new clusters of information.
           </p>
           <div className="flex gap-8 text-sm text-slate-500">
              <span>• Force Simulation</span>
              <span>• Collision Detection</span>
              <span>• Draggable Nodes</span>
           </div>
        </div>
      )
    },
    {
      id: 'challenges',
      title: "Technical Challenges",
      icon: <Shield className="w-6 h-6 text-orange-400" />,
      render: () => (
        <div className="h-full flex flex-col justify-center">
           <div className="space-y-6">
              <div className="bg-slate-900 p-4 rounded-lg border-l-4 border-orange-500">
                 <h3 className="text-white font-bold">Rate Limiting</h3>
                 <p className="text-sm text-slate-400">Preventing API 429 errors by implementing token bucket throttling.</p>
              </div>
              <div className="bg-slate-900 p-4 rounded-lg border-l-4 border-orange-500">
                 <h3 className="text-white font-bold">Infinite Loops</h3>
                 <p className="text-sm text-slate-400">Detecting cyclic graph dependencies (A -> B -> A) using Visited sets.</p>
              </div>
              <div className="bg-slate-900 p-4 rounded-lg border-l-4 border-orange-500">
                 <h3 className="text-white font-bold">State Management</h3>
                 <p className="text-sm text-slate-400">Syncing React state with async workers without race conditions.</p>
              </div>
           </div>
        </div>
      )
    },
    {
      id: 'roadmap',
      title: "Future Roadmap",
      icon: <BarChart className="w-6 h-6 text-cyan-400" />,
      render: () => (
        <div className="h-full flex flex-col justify-center">
           <div className="relative border-l-2 border-slate-700 ml-6 space-y-12">
              
              <div className="relative pl-8">
                 <div className="absolute -left-[9px] top-1 w-4 h-4 rounded-full bg-emerald-500 ring-4 ring-slate-900"></div>
                 <h3 className="text-emerald-400 font-bold">Phase 1: MVP (Complete)</h3>
                 <p className="text-slate-400 text-sm">Basic Crawling, Summarization, Local Storage.</p>
              </div>

              <div className="relative pl-8">
                 <div className="absolute -left-[9px] top-1 w-4 h-4 rounded-full bg-cyan-500 ring-4 ring-slate-900 animate-pulse"></div>
                 <h3 className="text-cyan-400 font-bold">Phase 2: Production (Current)</h3>
                 <p className="text-slate-400 text-sm">Concurrency, Grounding, Graph Viz, Error Recovery.</p>
              </div>

              <div className="relative pl-8">
                 <div className="absolute -left-[9px] top-1 w-4 h-4 rounded-full bg-slate-700 ring-4 ring-slate-900"></div>
                 <h3 className="text-slate-400 font-bold">Phase 3: Enterprise Cloud</h3>
                 <p className="text-slate-500 text-sm">Distributed workers, PostgreSQL Sync, PDF/Image Parsing.</p>
              </div>

           </div>
        </div>
      )
    },
    {
      id: 'metrics',
      title: "Performance Metrics",
      icon: <Target className="w-6 h-6 text-green-400" />,
      render: () => (
        <div className="grid grid-cols-2 gap-6 h-full content-center">
           <div className="bg-slate-800 p-6 rounded-xl text-center">
              <div className="text-4xl font-black text-white mb-2">98%</div>
              <div className="text-sm text-slate-400 uppercase tracking-wider">Uptime</div>
           </div>
           <div className="bg-slate-800 p-6 rounded-xl text-center">
              <div className="text-4xl font-black text-white mb-2">~1.2s</div>
              <div className="text-sm text-slate-400 uppercase tracking-wider">Avg Parse Time</div>
           </div>
           <div className="bg-slate-800 p-6 rounded-xl text-center">
              <div className="text-4xl font-black text-white mb-2">50+</div>
              <div className="text-sm text-slate-400 uppercase tracking-wider">Pages / Session</div>
           </div>
           <div className="bg-slate-800 p-6 rounded-xl text-center">
              <div className="text-4xl font-black text-white mb-2">0</div>
              <div className="text-sm text-slate-400 uppercase tracking-wider">Critical Failures</div>
           </div>
        </div>
      )
    },
    {
      id: 'team',
      title: "The Team",
      icon: <Users className="w-6 h-6 text-indigo-400" />,
      render: () => (
        <div className="h-full flex flex-col justify-center items-center">
           <h2 className="text-3xl font-bold text-white mb-12">Meet the Builders</h2>
           <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 w-full max-w-3xl">
            {team.map((member, i) => (
              <div key={i} className="flex items-center gap-4 p-4 rounded-xl bg-slate-900 border border-slate-800 hover:border-cyan-500/50 transition-colors">
                <div className="w-10 h-10 rounded-full bg-gradient-to-br from-cyan-900 to-blue-900 flex items-center justify-center text-sm font-bold text-cyan-300 shadow-inner">
                  {member.charAt(0)}
                </div>
                <span className="text-slate-200 font-medium text-lg">{member}</span>
              </div>
            ))}
          </div>
        </div>
      )
    },
    {
      id: 'launch',
      render: () => (
        <div className="flex flex-col items-center justify-center text-center h-full">
           <div className="w-24 h-24 bg-cyan-500/10 rounded-full flex items-center justify-center mb-8 animate-pulse">
              <Zap className="w-12 h-12 text-cyan-400" />
           </div>
           <h2 className="text-5xl font-bold text-white mb-6">System Ready</h2>
           <p className="text-xl text-slate-400 mb-12 max-w-xl">
              The SpiderWeb Crawler is initialized and awaiting your command.
           </p>
           <button 
             onClick={onClose}
             className="group flex items-center gap-3 bg-white text-slate-950 px-8 py-4 rounded-full font-bold text-xl hover:bg-cyan-400 transition-all transform hover:scale-105 shadow-2xl shadow-cyan-900/50"
           >
             Launch Application
             <ArrowRight className="w-6 h-6 group-hover:translate-x-1 transition-transform" />
           </button>
        </div>
      )
    }
  ];

  const handleNext = useCallback(() => {
    if (currentSlide < slides.length - 1) {
      setAnimating(true);
      setTimeout(() => {
        setCurrentSlide(p => p + 1);
        setAnimating(false);
      }, 300);
    }
  }, [currentSlide, slides.length]);

  const handlePrev = useCallback(() => {
    if (currentSlide > 0) {
      setAnimating(true);
      setTimeout(() => {
        setCurrentSlide(p => p - 1);
        setAnimating(false);
      }, 300);
    }
  }, [currentSlide]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'ArrowRight') handleNext();
      if (e.key === 'ArrowLeft') handlePrev();
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [handleNext, handlePrev, onClose]);

  const CurrentSlideRender = slides[currentSlide].render;

  return (
    <div className="fixed inset-0 z-50 bg-slate-950 text-slate-200 flex flex-col">
      {/* Top Bar */}
      <div className="h-16 border-b border-slate-800 flex items-center justify-between px-6 bg-slate-900/50 backdrop-blur-sm">
         <div className="font-black text-xl tracking-tighter">
            SPIDER<span className="text-cyan-400">WEB</span>
         </div>
         <div className="flex items-center gap-4">
            <div className="text-sm font-mono text-slate-500">
               Slide {currentSlide + 1} / {slides.length}
            </div>
            <button onClick={onClose} className="text-sm font-bold text-slate-400 hover:text-white uppercase tracking-wider">
               Skip
            </button>
         </div>
      </div>

      {/* Main Content Area */}
      <div className="flex-1 relative overflow-hidden flex items-center justify-center p-4 md:p-12">
         {/* Slide Title if exists */}
         {slides[currentSlide].title && (
            <div className={`absolute top-8 left-0 right-0 text-center transition-opacity duration-300 ${animating ? 'opacity-0' : 'opacity-100'}`}>
               <div className="flex items-center justify-center gap-3 mb-2">
                  {slides[currentSlide].icon}
                  <h3 className="text-sm font-bold text-cyan-400 uppercase tracking-widest">{slides[currentSlide].title}</h3>
               </div>
            </div>
         )}

         <div className={`w-full max-w-6xl h-full transition-all duration-300 transform ${animating ? 'opacity-0 scale-95 translate-y-4' : 'opacity-100 scale-100 translate-y-0'}`}>
            <CurrentSlideRender />
         </div>
      </div>

      {/* Bottom Navigation */}
      <div className="h-20 border-t border-slate-800 bg-slate-900/50 backdrop-blur-sm flex items-center justify-between px-6 md:px-12">
         <button 
            onClick={handlePrev}
            disabled={currentSlide === 0}
            className="p-2 rounded-full hover:bg-slate-800 disabled:opacity-30 disabled:cursor-not-allowed transition-colors"
         >
            <ChevronLeft className="w-8 h-8" />
         </button>

         {/* Progress Bar */}
         <div className="flex-1 mx-8 max-w-xl">
            <div className="h-1 bg-slate-800 rounded-full overflow-hidden">
               <div 
                  className="h-full bg-cyan-500 transition-all duration-500 ease-out"
                  style={{ width: `${((currentSlide + 1) / slides.length) * 100}%` }}
               ></div>
            </div>
         </div>

         <button 
            onClick={handleNext}
            disabled={currentSlide === slides.length - 1}
            className="p-2 rounded-full hover:bg-slate-800 disabled:opacity-30 disabled:cursor-not-allowed transition-colors"
         >
            <ChevronRight className="w-8 h-8" />
         </button>
      </div>
    </div>
  );
};
