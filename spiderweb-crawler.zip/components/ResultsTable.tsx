
import React, { useState, useEffect } from 'react';
import { CrawlResult } from '../types';
import { dbService } from '../services/db';
import { ExternalLink, Search, Loader2, Globe } from 'lucide-react';

interface ResultsTableProps {
  refreshTrigger: number; // prop to trigger refresh
}

export const ResultsTable: React.FC<ResultsTableProps> = ({ refreshTrigger }) => {
  const [results, setResults] = useState<CrawlResult[]>([]);
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    loadData();
  }, [refreshTrigger, search]);

  const loadData = async () => {
    setLoading(true);
    try {
      const data = search ? await dbService.search(search) : await dbService.getAllPages();
      // Sort by timestamp desc
      setResults(data.sort((a, b) => b.timestamp - a.timestamp));
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-slate-900 rounded-xl border border-slate-800 shadow-lg overflow-hidden flex flex-col h-[500px]">
      <div className="p-4 border-b border-slate-800 bg-slate-900/50 flex items-center justify-between">
        <h3 className="text-sm font-bold text-slate-400 uppercase tracking-wider">Indexed Data & Grounding Sources</h3>
        <div className="relative w-64">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
            <input 
                type="text" 
                placeholder="Search index..." 
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 text-slate-200 text-sm rounded-md pl-9 pr-3 py-1.5 focus:ring-1 focus:ring-cyan-500 focus:border-cyan-500 outline-none transition-all"
            />
        </div>
      </div>

      <div className="overflow-y-auto flex-1 p-0">
        {loading ? (
            <div className="flex items-center justify-center h-full text-slate-500">
                <Loader2 className="w-6 h-6 animate-spin mr-2" /> Loading...
            </div>
        ) : results.length === 0 ? (
             <div className="flex items-center justify-center h-full text-slate-500">
                No data found.
            </div>
        ) : (
            <table className="w-full text-left border-collapse">
            <thead className="bg-slate-950 sticky top-0 z-10 text-xs uppercase text-slate-400 font-semibold">
                <tr>
                <th className="px-6 py-3 border-b border-slate-800 w-1/3">Page Info</th>
                <th className="px-6 py-3 border-b border-slate-800 w-1/3">Grounding Sources (Real-time)</th>
                <th className="px-6 py-3 border-b border-slate-800 text-right">Links</th>
                <th className="px-6 py-3 border-b border-slate-800 text-right">Action</th>
                </tr>
            </thead>
            <tbody className="divide-y divide-slate-800">
                {results.map((page) => (
                <tr key={page.url} className="hover:bg-slate-800/50 transition-colors group">
                    <td className="px-6 py-4 align-top">
                        <div className="flex flex-col gap-1">
                            <span className="font-medium text-cyan-400 truncate max-w-md block" title={page.title}>
                                {page.title || "Untitled"}
                            </span>
                            <span className="text-xs text-slate-500 truncate max-w-md block">{page.url}</span>
                            <p className="text-sm text-slate-300 mt-1 line-clamp-2 text-xs opacity-80">
                                {page.summary}
                            </p>
                        </div>
                    </td>
                    <td className="px-6 py-4 align-top">
                        {page.sourceUrls && page.sourceUrls.length > 0 ? (
                            <ul className="space-y-1">
                                {page.sourceUrls.slice(0, 3).map((s, i) => (
                                    <li key={i} className="flex items-start gap-2 text-xs text-slate-400">
                                        <Globe className="w-3 h-3 mt-0.5 text-emerald-500 shrink-0" />
                                        <a href={s.uri} target="_blank" rel="noreferrer" className="hover:text-emerald-400 hover:underline truncate max-w-[200px]" title={s.title}>
                                            {s.title}
                                        </a>
                                    </li>
                                ))}
                                {page.sourceUrls.length > 3 && (
                                    <li className="text-xs text-slate-600 italic pl-5">+{page.sourceUrls.length - 3} more</li>
                                )}
                            </ul>
                        ) : (
                            <span className="text-xs text-slate-600 italic">No external sources</span>
                        )}
                    </td>
                    <td className="px-6 py-4 text-right font-mono text-sm text-slate-400 align-top">
                        {page.links.length}
                    </td>
                    <td className="px-6 py-4 text-right align-top">
                        <a 
                            href={page.url} 
                            target="_blank" 
                            rel="noopener noreferrer"
                            className="inline-flex items-center justify-center w-8 h-8 rounded-full bg-slate-800 hover:bg-cyan-900 hover:text-cyan-400 text-slate-400 transition-all"
                        >
                            <ExternalLink className="w-4 h-4" />
                        </a>
                    </td>
                </tr>
                ))}
            </tbody>
            </table>
        )}
      </div>
    </div>
  );
};
