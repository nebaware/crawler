import React, { useState } from 'react';
import { Play, Square, Trash2, Search } from 'lucide-react';

interface ControlPanelProps {
  isRunning: boolean;
  onStart: (seedUrl: string, concurrency: number) => void;
  onStop: () => void;
  onClear: () => void;
}

export const ControlPanel: React.FC<ControlPanelProps> = ({ isRunning, onStart, onStop, onClear }) => {
  const [url, setUrl] = useState('');
  const [concurrency, setConcurrency] = useState(2);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (url) onStart(url, concurrency);
  };

  return (
    <div className="bg-slate-900 p-6 rounded-xl border border-slate-800 shadow-lg mb-6">
      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="flex flex-col md:flex-row gap-4 items-end">
          <div className="flex-1 w-full">
            <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">
              Seed URL
            </label>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-500" />
              <input
                type="url"
                value={url}
                onChange={(e) => setUrl(e.target.value)}
                disabled={isRunning}
                className="w-full bg-slate-950 border border-slate-700 text-slate-200 pl-10 pr-4 py-2.5 rounded-lg focus:ring-2 focus:ring-cyan-500 focus:border-transparent transition-all disabled:opacity-50 disabled:cursor-not-allowed"
                placeholder="https://example.com"
                required
              />
            </div>
          </div>

          <div className="w-full md:w-48">
            <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">
              Threads: <span className="text-cyan-400">{concurrency}</span>
            </label>
            <input
              type="range"
              min="1"
              max="5"
              value={concurrency}
              onChange={(e) => setConcurrency(Number(e.target.value))}
              disabled={isRunning}
              className="w-full h-2 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-cyan-500"
            />
          </div>

          <div className="flex gap-2 w-full md:w-auto">
            {!isRunning ? (
              <button
                type="submit"
                className="flex-1 md:flex-none flex items-center justify-center gap-2 bg-cyan-600 hover:bg-cyan-500 text-white px-6 py-2.5 rounded-lg font-medium transition-all shadow-lg shadow-cyan-900/20"
              >
                <Play className="w-4 h-4 fill-current" />
                Start Crawl
              </button>
            ) : (
              <button
                type="button"
                onClick={onStop}
                className="flex-1 md:flex-none flex items-center justify-center gap-2 bg-rose-600 hover:bg-rose-500 text-white px-6 py-2.5 rounded-lg font-medium transition-all shadow-lg shadow-rose-900/20"
              >
                <Square className="w-4 h-4 fill-current" />
                Stop
              </button>
            )}
            
            <button
              type="button"
              onClick={onClear}
              disabled={isRunning}
              className="flex items-center justify-center p-2.5 border border-slate-700 hover:border-slate-600 text-slate-400 hover:text-slate-200 rounded-lg transition-all disabled:opacity-50 disabled:cursor-not-allowed"
              title="Clear Database"
            >
              <Trash2 className="w-5 h-5" />
            </button>
          </div>
        </div>
      </form>
    </div>
  );
};