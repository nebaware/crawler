import React from 'react';
import { Activity, Database, Layers, Clock } from 'lucide-react';
import { CrawlerStats } from '../types';

interface StatsCardProps {
  stats: CrawlerStats;
}

export const StatsCard: React.FC<StatsCardProps> = ({ stats }) => {
  const formatTime = (ms: number | null) => {
    if (!ms) return '00:00';
    const seconds = Math.floor((Date.now() - ms) / 1000);
    const m = Math.floor(seconds / 60);
    const s = seconds % 60;
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  // Force update time every second is handled by parent re-render or internal effect, 
  // but for simplicity we just render what is passed.

  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
      <div className="bg-slate-900 p-4 rounded-xl border border-slate-800">
        <div className="flex items-center gap-3 mb-2">
          <div className="p-2 bg-cyan-500/10 rounded-lg">
            <Database className="w-5 h-5 text-cyan-400" />
          </div>
          <span className="text-slate-400 text-sm font-medium">Pages Indexed</span>
        </div>
        <p className="text-2xl font-bold text-white pl-1">{stats.pagesCrawled}</p>
      </div>

      <div className="bg-slate-900 p-4 rounded-xl border border-slate-800">
        <div className="flex items-center gap-3 mb-2">
          <div className="p-2 bg-amber-500/10 rounded-lg">
            <Layers className="w-5 h-5 text-amber-400" />
          </div>
          <span className="text-slate-400 text-sm font-medium">Queue Depth</span>
        </div>
        <p className="text-2xl font-bold text-white pl-1">{stats.queueLength}</p>
      </div>

      <div className="bg-slate-900 p-4 rounded-xl border border-slate-800">
        <div className="flex items-center gap-3 mb-2">
          <div className="p-2 bg-emerald-500/10 rounded-lg">
            <Activity className="w-5 h-5 text-emerald-400" />
          </div>
          <span className="text-slate-400 text-sm font-medium">Active Threads</span>
        </div>
        <p className="text-2xl font-bold text-white pl-1">{stats.activeThreads}</p>
      </div>

      <div className="bg-slate-900 p-4 rounded-xl border border-slate-800">
        <div className="flex items-center gap-3 mb-2">
          <div className="p-2 bg-violet-500/10 rounded-lg">
            <Clock className="w-5 h-5 text-violet-400" />
          </div>
          <span className="text-slate-400 text-sm font-medium">Runtime</span>
        </div>
        <p className="text-2xl font-bold text-white pl-1">
          {stats.startTime ? formatTime(stats.startTime) : '--:--'}
        </p>
      </div>
    </div>
  );
};
