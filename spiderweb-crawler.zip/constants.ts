export const MAX_DEPTH_DEFAULT = 2;
export const MAX_PAGES_LIMIT = 50;
export const CONCURRENCY_DEFAULT = 2;

// D3 Constants
export const GRAPH_WIDTH = 600;
export const GRAPH_HEIGHT = 400;
export const NODE_RADIUS = 5;